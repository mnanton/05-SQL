-- Crear Esquema
create schema mnantond;

-- Creación de Tablas
create table mnantond.CompanyAuto(
	idCompany	serial		primary key,
	compañia	varchar(40)	not null,
	activo		bool 		not null);
	
create table mnantond.Marcas(
	idMarca		serial		primary key,
	idCompany	int			not null,
	marcas		varchar(40) not null,
	activo		bool		not null
);

create table mnantond.Grupos (
	idGrupo		serial		primary key,
	idMarca		int			not null,
	grupo		varchar(40)	not null,
	activo		bool		not null
);

create table mnantond.Modelos (
	idModelo	serial		primary key,
	idMarca		int			not null,
	idGrupo		int			not null,
	modelo		varchar(30)	not null,
	activo		bool		not null
);

create table mnantond.Colores (
	idColor		serial		primary key,
	idMarca 	int			not null,
	idGrupo		int			not null,
	color 		varchar(30)	not null,
	activo		bool		not null
);

create table mnantond.CompanySeguro (
	idSeguro	serial		primary key,
	aseguradora	varchar(50)	not null,
	activo		bool		not null
);

create table mnantond.SeguroAuto(
	npoliza		varchar(10)	primary key,
	idSeguro	int			not null,
	numBastidor	varchar(17)	not null,
	fecha_inicio	date	not null,
	fecha_fin		date	not null
);

create table mnantond.Vehiculos(
	numBastidor	varchar(17)	primary key,
	idMarca		int			not null,
	idGrupo		int			not null,
	idModelo	int			not null,
	idColor		int			not null,
	matricula	varchar(8)	not null,
	fecha_compra	date	not null,
	kmstotales	int			null
);

create table mnantond.Divisas(
	idDivisa	varchar(3)	primary key,
	divisa		varchar(10)	not null,
	activo		bool		not null
);

create table mnantond.Revisiones(
	idMantenimiento	serial		primary key,
	numBastidor		varchar(17)	not null,		
	kms				int			not null,
	fecha			date		not null,
	importe 		decimal		null,
	idDivisa		varchar(3)	null
);

-- Creación de Relaciones
alter table mnantond.Marcas   add constraint pk_Marcas_CompanyAuto foreign key (idCompany) references mnantond.CompanyAuto(idCompany);
alter table mnantond.Grupos   add constraint pk_Grupos_Marcas      foreign key (idMarca)   references mnantond.Marcas(idMarca);
alter table mnantond.Modelos  add constraint pk_Modelos_Marcas     foreign key (idMarca)   references mnantond.Marcas(idMarca);
alter table mnantond.Modelos  add constraint pk_Modelos_Grupos     foreign key (idGrupo)   references mnantond.Grupos(idGrupo);
alter table mnantond.Colores  add constraint pk_Colores_Marcas     foreign key (idMarca)   references mnantond.Marcas(idMarca);
alter table mnantond.Colores  add constraint pk_Colores_Grupos     foreign key (idGrupo)   references mnantond.Grupos(idGrupo);

alter table mnantond.Vehiculos  add constraint pk_vehiculos_Marcas  foreign key (idMarca)  references mnantond.Marcas(idMarca);
alter table mnantond.Vehiculos  add constraint pk_Vehiculos_Grupos  foreign key (idGrupo)  references mnantond.Grupos(idGrupo);
alter table mnantond.Vehiculos  add constraint pk_Vehiculos_Modelos foreign key (idModelo) references mnantond.Modelos(idModelo);
alter table mnantond.Vehiculos  add constraint pk_Vehiculos_Colores foreign key (idModelo) references mnantond.Colores(idColor);

alter table mnantond.SeguroAuto  add constraint pk_Seguro_Company  foreign key (idSeguro)    references mnantond.CompanySeguro(idSeguro);
alter table mnantond.SeguroAuto  add constraint pk_Seguro_Vehiculo foreign key (numBastidor) references mnantond.Vehiculos(numBastidor);

alter table mnantond.Revisiones  add constraint pk_Revisiones_Vehiculo foreign key (numBastidor) references mnantond.Vehiculos(numBastidor);
alter table mnantond.Revisiones  add constraint pk_Revisiones_Divisas  foreign key (idDivisa)    references mnantond.Divisas(idDivisa);

-- Inserción de Datos
insert into mnantond.companyauto (compañia,activo) values ('STELLANTIS',TRUE);
insert into mnantond.companyauto (compañia,activo) values ('VOLKSWAGEN',TRUE);
insert into mnantond.companyauto (compañia,activo) values ('BMW',TRUE);
insert into mnantond.companyauto (compañia,activo) values ('SAIC',TRUE);

insert into mnantond.Marcas (idCompany,marcas,activo) values (1,'JEEP',TRUE);
insert into mnantond.Marcas (idCompany,marcas,activo) values (2,'AUDI',TRUE);
insert into mnantond.Marcas (idCompany,marcas,activo) values (3,'MINI',TRUE);
insert into mnantond.Marcas (idCompany,marcas,activo) values (4,'MG',TRUE);

insert into mnantond.Grupos (idMarca,grupo,activo) values (1,'RENEGADE',TRUE);
insert into mnantond.Grupos (idMarca,grupo,activo) values (2,'TT',TRUE);
insert into mnantond.Grupos (idMarca,grupo,activo) values (3,'COOPER',TRUE);
insert into mnantond.Grupos (idMarca,grupo,activo) values (4,'ZS',TRUE);

insert into mnantond.Modelos (idMarca,idGrupo,Modelo,activo) values (1,1,'TRAILHAWK',TRUE);
insert into mnantond.Modelos (idMarca,idGrupo,Modelo,activo) values (2,2,'TFSI TOURIST',TRUE);
insert into mnantond.Modelos (idMarca,idGrupo,Modelo,activo) values (3,3,'SE',TRUE);
insert into mnantond.Modelos (idMarca,idGrupo,Modelo,activo) values (4,4,'EV',TRUE);

insert into mnantond.Colores (idMarca,idGrupo,color,activo) values (1,1,'NEGRO',TRUE);
insert into mnantond.Colores (idMarca,idGrupo,color,activo) values (2,2,'BLANCO POLAR',TRUE);
insert into mnantond.Colores (idMarca,idGrupo,color,activo) values (3,3,'BLANCO ALPINE',TRUE);
insert into mnantond.Colores (idMarca,idGrupo,color,activo) values (4,4,'ROJO DIAMOND',TRUE);

insert into mnantond.companyseguro (ASEGURADORA,ACTIVO) values ('MAPFRE',TRUE);
insert into mnantond.companyseguro (ASEGURADORA,ACTIVO) values ('AXA',TRUE);
insert into mnantond.companyseguro (ASEGURADORA,ACTIVO) values ('ALLIANZ RAS',TRUE);
insert into mnantond.companyseguro (ASEGURADORA,ACTIVO) values ('GENERALI',TRUE);

insert into mnantond.Vehiculos(numBastidor,idMarca,idGrupo,idModelo,idColor,Matricula,fecha_compra,kmstotales)
                       values ('JFA12AA0123456789',1,1,1,1,'1111AAA','2023/01/01',1100);
insert into mnantond.Vehiculos(numBastidor,idMarca,idGrupo,idModelo,idColor,Matricula,fecha_compra,kmstotales)
                       values ('JFA12BB0123456789',2,2,2,2,'2222AAA','2023/02/01',1200);
insert into mnantond.Vehiculos(numBastidor,idMarca,idGrupo,idModelo,idColor,Matricula,fecha_compra,kmstotales)
                       values ('JFA12CC0123456789',3,3,3,3,'3333AAA','2023/03/01',1300);
insert into mnantond.Vehiculos(numBastidor,idMarca,idGrupo,idModelo,idColor,Matricula,fecha_compra,kmstotales)
                       values ('JFA12DD0123456789',4,4,4,4,'4444AAA','2023/04/01',1400);

insert into mnantond.seguroauto (npoliza,idSeguro,numBastidor,fecha_inicio,fecha_fin) 
					     values ('A123456789',1,'JFA12AA0123456789','2023/01/01','2024/01/01');
					    
insert into mnantond.seguroauto (npoliza,idSeguro,numBastidor,fecha_inicio,fecha_fin) 
					     values ('B123456789',2,'JFA12BB0123456789','2023/02/01','2024/02/01');
					    
insert into mnantond.seguroauto (npoliza,idSeguro,numBastidor,fecha_inicio,fecha_fin) 
					     values ('C123456789',3,'JFA12CC0123456789','2023/03/01','2024/03/01');
					
insert into mnantond.seguroauto (npoliza,idSeguro,numBastidor,fecha_inicio,fecha_fin) 
					     values ('D123456789',4,'JFA12DD0123456789','2023/04/01','2023/09/01');
					    
insert into mnantond.divisas (idDivisa,divisa,activo) values ('EUR','EUROS',TRUE);
insert into mnantond.divisas (idDivisa,divisa,activo) values ('DOL','DOLARES',TRUE);
insert into mnantond.divisas (idDivisa,divisa,activo) values ('GBP','LIBRAS',TRUE);

insert into mnantond.revisiones (numBastidor,Kms,fecha,IMPORTE,idDivisa)
					     values ('JFA12AA0123456789',1100,'2023/02/15',45.10,'EUR');
					    
insert into mnantond.revisiones (numBastidor,Kms,fecha,IMPORTE,idDivisa)
					     values ('JFA12BB0123456789',1200,'2023/03/16',45.10,'EUR');

insert into mnantond.revisiones (numBastidor,Kms,fecha,IMPORTE,idDivisa)
					     values ('JFA12CC0123456789',1300,'2023/04/17',45.10,'EUR');
					    
insert into mnantond.revisiones (numBastidor,Kms,fecha,IMPORTE,idDivisa)
					     values ('JFA12DD0123456789',1400,'2023/05/18',NULL,NULL);

-- Consulta SQL

select mnantond.companyauto.compañia , mnantond.marcas.marcas, mnantond.grupos.grupo , mnantond.modelos.modelo ,mnantond.colores.color, mnantond.vehiculos.fecha_compra,
       mnantond.vehiculos.matricula, mnantond.vehiculos.kmstotales, mnantond.companyseguro.aseguradora, mnantond.seguroauto.npoliza 
from mnantond.vehiculos
inner join mnantond.marcas  on mnantond.marcas.idmarca = mnantond.vehiculos.idmarca 
inner join mnantond.grupos  on mnantond.grupos.idgrupo = mnantond.vehiculos.idgrupo and mnantond.grupos.idmarca = mnantond.vehiculos.idmarca 
inner join mnantond.modelos on mnantond.modelos.idmodelo  = mnantond.vehiculos.idmodelo and mnantond.grupos.idmarca = mnantond.vehiculos.idmarca and mnantond.modelos.idgrupo = mnantond.vehiculos.idgrupo 
inner join mnantond.colores on mnantond.colores.idcolor  = mnantond.vehiculos.idcolor and mnantond.colores.idmarca = mnantond.vehiculos.idmarca and mnantond.colores.idgrupo = mnantond.vehiculos.idgrupo 
inner join mnantond.seguroauto    on mnantond.seguroauto.numbastidor = mnantond.vehiculos.numbastidor 
inner join mnantond.companyseguro on mnantond.companyseguro.idseguro = mnantond.seguroauto.idseguro 
inner join mnantond.companyauto   on mnantond.marcas.idcompany=mnantond.companyauto.idcompany
where mnantond.seguroauto.fecha_fin>now()

